#include "types.h"

struct vmstat
{
    uint64 total_memory;
    uint64 free_memory;
    uint64 used_memory;
    uint64 resident_pages;
    uint64 process_memory;
};
