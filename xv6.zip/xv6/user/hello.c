#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main()
{
    printf("Hello world, this is Scott Koss.\n");
    printf("I am in cs 370, Fall of 2024, section 1002. \n\n");

    exit(0);
}