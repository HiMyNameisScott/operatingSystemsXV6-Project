

#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int twinprime(int val);
int main(int argc, char * argv[]){
    int MAX_PROC = 8;
    int LIMIT = 1000000;
    //int pid;
    debug(1);

    for (int i = 0 ; i < MAX_PROC ; i++){
        int childPid;
        int runLength;

        if (i == 0 ||i == 1){
            runLength = 6;
            childPid = forkBQ(6);
            
        } else if (i == 2 || i == 3) {
            runLength = 4;
            childPid = forkBQ(4);

        } else if (i == 4 || i == 5) {
            runLength = 2;
            childPid = forkBQ(2);

        } else {
            runLength = 0;
            childPid = fork();
        }


        if (childPid > 0){
            printf("%d\n Child Process with a Run Length of: ", runLength);
        } else if (childPid == 0){
            printf("Child pid = %d, total twin primes = %d\n", getpid(), twinprime(LIMIT));
            exit(0);
        } else {
            printf("Error! Unable to create child Process");
            exit(1);
        }
    }

    for (int i = 0 ; i < MAX_PROC ; i++){
        wait((int *) 0);
    }

    debug(0);
    return 0;
}

/// @brief 
/// @param valOne 
/// @return 
int twinprime(int val){
    int pCount = 0;                 // This will hold the num of twin primes
    int numOnePrime;                // This is "bool" tracks #1 if its prime
    int numTwoPrime;                // This is "bool" tracks #2 if its prime
                                    // Initially started as iterating through all numbers
                                    // After a bit of reasearch learned about prime factorization
                                    // Utilizing this to implement solution as its easier to track

    for (int i = 2; i <= val-2 ; i++){
        numOnePrime = 1;           // True; tracks if prime
        numTwoPrime = 1;           // True; tracks if prime

        for (int j = 2 ; j*j <= i && numOnePrime == 1 ; j++){
            if (i % j == 0){
                numOnePrime = 0;
            }
        }

        if (numOnePrime == 1){
            for (int j = 2 ; j*j <= i+2 && numTwoPrime == 1 ; j++){
                if ((i + 2) % j ==0){
                    numTwoPrime = 0;
                }
            }
        }

        if (numOnePrime == 1 && numTwoPrime == 1){
            pCount++;
        }

    }

    return pCount;
}