// Scott T. Koss
// 1013095342
// Modekruthy - 1003

#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
#include "kernel/fcntl.h"

int main(int argc, char * argv[]){

    int current_time = uptime();        // Holds the first time for calc time
    int second_time = 0;                // Holds second time for calc
    int difference_time = 0;            // holds cur - sec

    if (argc < 2){
        printf("Usage Msg\n");          // error if no args passed
        exit(1);
    }

    //pid == 0 is the child code
    // pid > 0 is the parent code.

    int pid = fork();                   // assign int pid to a fork
                                        // fork returns an int we check the int
                                        // So we know what to do below
    // if the pid
    //pid == 0 is the child code
    // pid > 0 is the parent code.
    if (pid > 0){
        pid = wait((int *) 0);
        second_time = uptime();
        difference_time = second_time - current_time;
    } else if(pid == 0) {
        exec(argv[1], argv+1);
        exit(0);
    } else {
        printf("Error Wil Robinson, Error!");
        exit(1);
    }
    
    // Print the calculations
    printf("Seconds: %d\n", (difference_time % 100));
    
    printf("Sub Seconds: %d\n", ((difference_time) % 100 ) * 1000);


    exit(0);
}