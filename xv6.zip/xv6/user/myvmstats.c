// Scott T. Koss
// cs370 - Modekurthy
// Project 4 

#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/vmstat.h"

/// @brief Used to test that values are being assigned to the dynamically allocated arr
/// @param arr The array that has been allocated
/// @param arr_sz The number of values allocated to the array
void testAllocation(int arr[], int arr_sz);


int main(){

    // a struct to store our values to update
    struct vmstat stats = {0};

    // Block for updating stats struct, and displaying memory.
    vmstats((uint64)&stats);
    printf("Scott Koss, xv6 Memory Stats\n\n");
    printf("Total memory: \t%ld\n", stats.total_memory);
    printf("Free memory: \t%ld\n", stats.free_memory);
    printf("Used memory: \t%ld\n", stats.used_memory);
    printf("Resident pages memory: \t%ld\n", stats.resident_pages);
    printf("Process memory: \t%ld\n\n", stats.process_memory);

    // mallocs a bunch of int sized values
    int array_sz = 32768;
    int* array = (int*) malloc(array_sz * sizeof(int));

    // assigns values to the newly created array
    for (int i = 0 ; i < array_sz ; i++){
        array[i] = 1 + i;
    }

    // testAllocation(array, array_sz);

    // Check to make sure that values actuallly allocated
    if (array == 0){
        printf("Failed to Alloc\n\n");
        return 1;
    } else {
        printf("Memory successfully allocated using malloc.\n\n");
    }

    // Second update/information block to show changes.
    vmstats((uint64)&stats);
    printf("Scott Koss, xv6 Memory Stats\n\n");
    printf("Total memory: \t%ld\n", stats.total_memory);
    printf("Free memory: \t%ld\n", stats.free_memory);
    printf("Used memory: \t%ld\n", stats.used_memory);
    printf("Resident pages memory: \t%ld\n", stats.resident_pages);
    printf("Process memory: \t%ld\n\n", stats.process_memory);

    // Free the allocated space since we no longer need it.
    free(array);

    return(0);
}

void testAllocation(int arr[], int arr_sz){

    for (int i = 0; i < arr_sz; i++) {
        printf("array[%d] = %d\n", i, arr[i]);
    }
}