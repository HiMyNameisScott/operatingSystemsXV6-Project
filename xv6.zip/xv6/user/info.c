// Scott Koss
// cs370
// Modekurthy 1003

#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"



int main(){
    sysinfo();
    exit(0);
}